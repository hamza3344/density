﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace probabilitydensity
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            List<double> numbers = new List<double>();
            foreach(string s in textBox1.Text.Split(","))
            {
                numbers.Add(double.Parse(s));
            }
            double mean = numbers.Average();
            var sqaured = numbers.Sum(d => Math.Pow(d - mean, 2));
            double std = Math.Sqrt(sqaured / numbers.Count());
            double x = double.Parse(textBox2.Text);
            double epart = Math.Pow(x - mean, 2) / (2 * Math.Pow(std, 2));
            double density = (1 / (std * 2.50662827463)) * (Math.Exp(0.0 - epart));
            MessageBox.Show(" " + density);
        }
    }
}
